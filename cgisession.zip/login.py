#!/usr/bin/env python
# -*- coding: utf-8 -*-

from session import set_auth_cookie

set_auth_cookie("cookietest", "localhost", "usuario1", "clave123")