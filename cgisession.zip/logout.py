#!/usr/bin/env python
# -*- coding: utf-8 -*-

from session import remove_auth_cookie

remove_auth_cookie("cookietest", "localhost")